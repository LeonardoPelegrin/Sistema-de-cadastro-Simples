package ac2;
public class AC2 {
    public static void main(String[] args) {
        
    }
    
}
